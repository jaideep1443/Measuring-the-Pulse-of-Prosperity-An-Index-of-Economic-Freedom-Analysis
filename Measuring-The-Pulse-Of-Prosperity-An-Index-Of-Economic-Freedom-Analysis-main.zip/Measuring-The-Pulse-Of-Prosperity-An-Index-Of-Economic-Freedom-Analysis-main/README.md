# Measuring-The-Pulse-Of-Prosperity-An-Index-Of-Economic-Freedom-Analysis
A data-driven analysis of global economic freedom to understand its impact on national prosperity.
